function kalkulal(){
    
}